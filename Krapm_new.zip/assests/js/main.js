
//  STICKY HEADER MENU  
window.addEventListener("scroll", function(){
  var header = document.querySelector("header");
  header.classList.toggle("sticky", window.scrollY > 0);
});

//  Smooth Scroll
  const scroll = new SmoothScroll('.navbar a[href*="#"]', {
	speed: 500
});

//  ANIMATION ON SCROLL
  AOS.init({
    //offset: 400,
    //duraction: 2000
  });


// TYPEING SECTION
var typed = new Typed('.type', {
    strings: [
        'FOCUS. FAST FORWARD. FUTURE.',
        'WE ARE CREATIVE', 
        'WE LOVE DESIGN'
        ],
    typeSpeed: 60,
    backSpeed: 60,
    loop: true
});


//  READ MORE AND READ LESS BUTTON EVENT
const readMoreBtn = document.querySelector(".read-more-btn");
const text = document.querySelector(".text");

readMoreBtn.addEventListener("click", (e) => {
  text.classList.toggle("show-more");
  if (readMoreBtn.innerText === "Read More") {
    readMoreBtn.innerText = "Read Less";
  } else {
    readMoreBtn.innerText = "Read More";
  }
});


// OWL CAROUSEL 
$('.owl-carousel').owlCarousel({
  loop:false,
  center: true,
  stagePadding: 50,
  margin: 10,
  smartSpeed:1500,
  responsive:{
      0:{
          items:1,
          stagePadding: 30,
        },
      360:{
        items:1,
        stagePadding: 20,
        margin:12,
      },
      400:{
          items:1,
          stagePadding: 30,
      },
      1024:{
        items:1,
        stagePadding: 100,
      },
      1200:{
          items:2
      }
    }
});


// TECH KITCHEN COLLAPSE

/* 

  $("#toggle").click(function() {
    $(this).toggleClass("on");
    $("#menu").slideToggle(500);
  });

*/

$(document).ready(function(){

  $("#menu").hide();

    $("#toggle").click(function(){

      $("#menu").slideToggle(500);

  });

});
